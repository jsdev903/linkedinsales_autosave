// ==UserScript==
// @name         Sales Navigator Auto Add to List & Create List
// @namespace    https://www.linkedin.com
// @version      0.1
// @description  Sales Navigator Auto Add to List & Create List
// @author       Tahmidur Rahman
// @match        https://www.linkedin.com/sales/search/people?*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tampermonkey.net
// @grant        none
// ==/UserScript==

//adds a delay
async function delay(ms){await new Promise(resolve=>setTimeout(resolve,ms))}

async function createaList(){
    await delay(3000)
    //click + icon to createlist
    try{document.querySelector('.save-to-list-dropdown__content-container [type="plus-icon"]').click()}catch(e){document.querySelector('[aria-label="Create lead list"]').click();}
    await delay(3000)
    //input listname
    document.querySelector('[data-test-modal] input').value = new Date().toLocaleString();
    await delay(3000)
    document.querySelector('[data-test-modal] input').dispatchEvent(new Event('keyup',{bubbles:true}))
    await delay(3000)
    //savelist
    document.querySelector('[data-x--lists--create-modal-save-button]').click();
    await delay(3000);
}

async function createifNocustomList(){
    //if there is no customlist create list
    if(document.querySelector('[aria-labelledby^="custom_lists_header_ember"]')===null){
        await createaList();
        document.querySelector('[aria-label="Next"]').click();
        await delay(3000);
    }
    //if list is full > 950 create new list
    else if(Number(document.querySelector('.save-to-list-dropdown__content').children[1].innerText.split('\n')[1].replace('(','').replace(')','') > 950)){
        await createaList();
         await delay(3000);
    }
}

async function attemptToAdd(){
    await checknsave();
    await createifNocustomList();
    document.querySelector('.save-to-list-dropdown__content').children[1].querySelector('div').dispatchEvent(new Event('focus'));
    document.querySelector('.save-to-list-dropdown__content').children[1].querySelector('div').dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    await delay(3000);
    document.querySelector('[aria-label="Next"]').click()
    await delay(3000);
}

async function checknsave(){
    //if checkboxAll unselected select
    if(!document.querySelector('[id^="multi-selector-checkbox-ember"]').checked){
        await delay(3000)
        document.querySelector('[id^="multi-selector-checkbox-ember"]').click();
        await delay(3000)
        //click savetolist button which then opens a context menu
        document.querySelector('[aria-label="Save all selected leads to a custom list."]').click()
        await delay(1000)
    }
}

(async function() {
    'use strict';
    while(1){
        try{
            await delay(30000)
            await attemptToAdd();
        }catch(e){}
    }
})();